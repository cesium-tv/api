import numbers
from urllib.parse import urlparse

from vidsrc.auth.peertube import PeerTubeAuth
from vidsrc.models import Video, VideoSource


class PeerTubeCrawler:
    def __init__(self, channel, options, VideoModel=Video,
                 VideoSourceModel=VideoSource):
        self.url = channel.url
        self.channel_name = channel.name
        self.options = options
        self.VideoModel = VideoModel
        self.VideoSourceModel = VideoSourceModel

    def crawl(self, state):
        auth = PeerTubeAuth(self.url).login(self.options.credentials)

        urlp = urlparse(url)
        # http://cesium.tv/api/v1/video-channels/btimby_channel@cesium.tv:80
        port = urlp.port or 443 if urlp.scheme == 'https' else 80
        url = urljoin(
            self.url,
            '/api/v1/video-channels/',
            f'{self.channel_name}@{urlp.hostname}:{urlp.port}'
        )

        while True:
            results = requests.get(url, params={
                'start': state['start'],
                'count': 25,
                'sort': '-publishedAt',
                'skipCount': 'true',
                'nsfw': 'true',
            }, **auth).json()

            if not results:
                break

            for result in results['data']:
                obj = requests.get(
                    urljoin(self.url, f"/api/v1/videos/{result['shortUUID']}"),
                    **auth,
                ).json()
                files = obj.pop('files')

                sources = []
                for file in files:
                    sources.append(self.VideoSourceModel(
                        width = file['resolution']['id'],
                        fps = file['fps'],
                        size = file['size'],
                        url = file['fileUrl'],
                        original=file,
                    ))

                tags = list(obj['tags'])
                tags.append(obj['category']['label'])

                video = self.VideoModel(
                    title=obj['name'],
                    poster=urljoin(self.url, obj['thumbnailPath']),
                    duration=obj['duration'],
                    original=obj,
                )
                video.set_tags(tags)
                video.set_sources(sources)

                state = { 'start': state.get('start', 0) + 1 }
                yield video, state

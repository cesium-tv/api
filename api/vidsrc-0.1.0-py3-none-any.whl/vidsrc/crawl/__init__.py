from vidsrc.crawl.timcast import TimcastCrawler
from vidsrc.crawl.peertube import PeerTubeCrawler
from vidsrc.crawl.rumble import RumbleCrawler

from dataclasses import dataclass


@dataclass
class VideoSource:
    width: int
    height: int
    fps: int
    size: int
    url: str
    original: dict


@dataclass
class Video:
    tags: list[str]
    title: str
    poster: str
    duration: int
    sources: list[VideoSource]
    original: dict

    def set_tags(self, tags):
        self.tags = tags

    def set_sources(self, sources):
        self.sources = sources

class RumbleAuth:
    def __init__(self, url):
        self.url = url

    def login(self, credentials, headless=True, retry=3, timeout=2000):
        pass

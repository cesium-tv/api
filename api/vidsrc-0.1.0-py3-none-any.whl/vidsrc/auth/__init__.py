from vidsrc.auth.timcast import TimcastAuth
from vidsrc.auth.peertube import PeerTubeAuth
from vidsrc.auth.rumble import RumbleAuth
